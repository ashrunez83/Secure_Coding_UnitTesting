// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>

int main()
{
  std::cout << "Buffer Overflow Example" << std::endl;

  // TODO: The user can type more than 20 characters and overflow the buffer, resulting in account_number being replaced -
  //  even though it is a constant and the compiler buffer overflow checks are on.
  //  You need to modify this method to prevent buffer overflow without changing the account_number
  //  variable, and its position in the declaration. It must always be directly before the variable used for input.
  //  You must notify the user if they entered too much data.

  const std::string account_number = "CharlieBrown42";
  char user_input[20];

  std::cout << "Enter a value: ";

  //limit the amount of data copied into character array
  std::cin.getline(user_input, 20);

//validation check to detect if input is longer than the allowed number of characters
  if (std::cin.fail())
  {
  //clear the error state and remove any remaining characters from the input stream
    std::cin.clear();
    std::cin.ignore(1000, '\n');
    std::cout << "Error: Input Exceeded 19 characters." << std::endl; //error message notifies user when character limit is exceeded
    return 1;
  }

  std::cout << "You entered: " << user_input << std::endl;
  std::cout << "Account Number = " << account_number << std::endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
